
#!/bin/bash
sudo useradd -m -g users -p asdf giovanna  # cria o usuario giovanna com senha (criptografada) asdf
sudo usermod -p $(openssl passwd -1 giovanna) giovanna # altera a senha usuario giovanna para senha giovanna em texto plano 

sudo useradd -m -g users -p asdf matheus  # cria o usuario matheus com senha (criptografada) asdf
sudo usermod -p $(openssl passwd -1 matheus) matheus # altera a senha usuario paulo para senha matheus em texto plano 
